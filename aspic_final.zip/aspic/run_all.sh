#!/bin/sh
sudo ./src/rchi/rchimain &&
sudo ./src/lfi/lfimain &&
sudo ./src/gmlfi/mlfimain &&
sudo ./src/rcmi/rcmimain &&
sudo ./src/rcqi/rcqimain &&
sudo ./src/ni/nimain &&
sudo ./src/esi/esimain &&
sudo ./src/kmii/kmiimain &&
sudo ./src/hf1i/hf1imain &&
sudo ./src/cwi/cwimain &&
sudo ./src/li/limain &&
sudo ./src/rpi/rpi3main &&
sudo ./src/dwi/dwimain &&
sudo ./src/mhi/mhimain &&
sudo ./src/rgi/rgimain &&
sudo ./src/gmssmi/mssmimain &&
sudo ./src/gripi/ripimain &&
sudo ./src/ai/aimain &&
sudo ./src/cnai/cnaimain &&
sudo ./src/cnbi/cnbimain &&
sudo ./src/osti/ostimain &&
sudo ./src/wri/wrimain &&
sudo ./src/sfi/sfimain
